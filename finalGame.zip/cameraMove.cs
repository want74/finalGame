﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
// my script
public class cameraMove : MonoBehaviour
{
	Rigidbody rb;
    public GameObject bullet;
    public Text hpText;
    GameObject bulletClone;
    Rigidbody rbClone;
    int hpt = 100;

    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody>();
    }

    void FixedUpdate()
    {
        float moveHorizontal = Input.GetAxis("Horizontal");
        float moveVertical = Input.GetAxis("Vertical");
        rb.AddForce(transform.forward * moveVertical * 10f);
        transform.Rotate(0,moveHorizontal*5f,0);
        if(Input.GetKeyDown("space"))
        {
            bulletClone = Instantiate(bullet, new Vector3(transform.position.x, transform.position.y, transform.position.z), Quaternion.identity);
            rbClone = bulletClone.GetComponent<Rigidbody>();
            rbClone.AddForce(transform.forward * 500f);
        }
        if(hpt <= 0)
        {
            SceneManager.LoadScene(1);
        }
        
    }

    void OnCollisionEnter(Collision Collision)
    {
        if(Collision.gameObject.tag == "Enemy")
        {
            hpt --;
            hpText.text = "HP:" + hpt;
        }
    }
}

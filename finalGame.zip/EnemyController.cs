﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.AI;
using UnityEngine.SceneManagement;

public class EnemyController : MonoBehaviour
{
	public Transform playerTF;
	public NavMeshAgent Agent;
    public GameObject me;
    public Text score;
    static int scoreINT = 0;
    //Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        Agent.SetDestination(playerTF.transform.position);
        
    }

    void OnCollisionEnter(Collision Collision)
    {
        if(Collision.gameObject.tag == "Bullet")
        {
            scoreINT ++;
            score.text = "Score:" + scoreINT;
            Destroy(me);
            if(scoreINT >= 4)
            {
                SceneManager.LoadScene(0);
                scoreINT = 0;
            }
        }
    }
}
